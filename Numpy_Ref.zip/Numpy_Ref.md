

```python
import numpy as np
```


```python
a = np.array([[1,2,3],
              [4,5,6]])
```


```python
a
```




    array([[1, 2, 3],
           [4, 5, 6]])




```python
a.shape
```




    (2, 3)




```python
b = a*a
```


```python
b
```




    array([[ 1,  4,  9],
           [16, 25, 36]])




```python
a = np.ones((1,3))
```


```python
import matplotlib.pyplot as plt
```


```python
x =([[1,2],
   [3,4]])
```


```python
import random
random_matrix = [[random.random() for e in range(2)] for e in range(2)]
```


```python
random_matrix
```




    [[0.3062733232835744, 0.046400740437791965],
     [0.38782831217914815, 0.7595593584313726]]




```python
c = np.matmul(x,random_matrix)
```


```python
c
```




    array([[1.08192995, 1.56551946],
           [2.47013322, 3.17743966]])




```python
z = np.array([[5,6],[7,8]])
```


```python
z
```




    array([[5, 6],
           [7, 8]])




```python
z.shape
```




    (2, 2)




```python
k = np.dot(x,z)
```


```python
k
```




    array([[19, 22],
           [43, 50]])




```python
x
```




    [[1, 2], [3, 4]]




```python
n = np.array([10,20])
```


```python
n = n + [5]
```


```python
n**2
```




    array([225, 625], dtype=int32)




```python
np.sqrt(a)
```




    array([[1., 1., 1.]])




```python
a = np.array([1, 2, 3]) 
print(a)
```

    [1 2 3]
    


```python
a = np.array([1, 2, 3], dtype = 'int8') 
print(a)
```

    [1 2 3]
    


```python
a
```




    array([1, 2, 3], dtype=int8)




```python
import numpy as np 
dt = np.dtype([('age',np.int32)]) 
print(dt) 
```

    [('age', '<i4')]
    


```python
import numpy as np 
student = np.dtype([('name','S20'), ('age', 'i1'), ('marks', 'f4')]) 
print(student)
```

    [('name', 'S20'), ('age', 'i1'), ('marks', '<f4')]
    


```python
student = np.dtype([('name','S20'), ('age', 'i1'), ('marks', 'f4')]) 
a = np.array([('abc', 21, 50),('xyz', 18, 75)], dtype = student) 
print(a)
```

    [(b'abc', 21, 50.) (b'xyz', 18, 75.)]
    


```python
student
```




    dtype([('name', 'S20'), ('age', 'i1'), ('marks', '<f4')])



'b' − boolean

'i' − (signed) integer

'u' − unsigned integer

'f' − floating-point

'c' − complex-floating point

'm' − timedelta

'M' − datetime

'O' − (Python) objects

'S', 'a' − (byte-)string

'U' − Unicode

'V' − raw data (void)


```python
a = np.array([[1,2,3],[4,5,6]]) 
a.shape = (3,2) 
print(a)
```

    [[1 2]
     [3 4]
     [5 6]]
    


```python
a = np.array([[1,2,3],[4,5,6]]) 
b = a.reshape(3,2) 
print(b)
```

    [[1 2]
     [3 4]
     [5 6]]
    


```python
k = np.ones((3,3),dtype='int8')
```


```python
k
```




    array([[1, 1, 1],
           [1, 1, 1],
           [1, 1, 1]], dtype=int8)




```python
l = np.zeros((3,3,3,3,3),dtype='int8')
```


```python
l
```




    array([[[[[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]]],
    
    
            [[[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]]],
    
    
            [[[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]]]],
    
    
    
           [[[[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]]],
    
    
            [[[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]]],
    
    
            [[[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]]]],
    
    
    
           [[[[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]]],
    
    
            [[[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]]],
    
    
            [[[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]],
    
             [[0, 0, 0],
              [0, 0, 0],
              [0, 0, 0]]]]], dtype=int8)




```python
l.ndim
```




    5




```python
l.itemsize
```




    1




```python
a.itemsize
```




    4




```python
a
```




    array([[1, 2, 3],
           [4, 5, 6]])



1	
C_CONTIGUOUS (C)

The data is in a single, C-style contiguous segment

2	
F_CONTIGUOUS (F)

The data is in a single, Fortran-style contiguous segment

3	
OWNDATA (O)

The array owns the memory it uses or borrows it from another object

4	
WRITEABLE (W)

The data area can be written to. Setting this to False locks the data, making it read-only

5	
ALIGNED (A)

The data and all elements are aligned appropriately for the hardware

6	
UPDATEIFCOPY (U)

This array is a copy of some other array. When this array is deallocated, the base array will be updated with the contents of this array


```python
a.flags
```




      C_CONTIGUOUS : True
      F_CONTIGUOUS : False
      OWNDATA : True
      WRITEABLE : True
      ALIGNED : True
      WRITEBACKIFCOPY : False
      UPDATEIFCOPY : False



1	
a

Input data in any form such as list, list of tuples, tuples, tuple of tuples or tuple of lists

2	
dtype

By default, the data type of input data is applied to the resultant ndarray

3	
order

C (row major) or F (column major). C is default


```python
# convert list to ndarray 
import numpy as np 

x = [1,2,3] 
a = np.asarray(x) 
print(a)
```

    [1 2 3]
    


```python
m = (1,2,3)
```


```python
m = np.asarray(m)
```


```python
m
```




    array([1, 2, 3])




```python
m = list(m)
```


```python
m
```




    [1, 2, 3]




```python
m.append(4)
```


```python
m
```




    [1, 2, 3, 4]




```python
m = tuple(m)
```


```python
m
```




    (1, 2, 3, 4)




```python
z = [(1,2),(3,4)]
```


```python
j = np.asarray(z)
```


```python
j
```




    array([[1, 2],
           [3, 4]])



Syntax:
numpy.frombuffer(buffer, dtype = float, count = -1, offset = 0)


1	
buffer

Any object that exposes buffer interface

2	
dtype

Data type of returned ndarray. Defaults to float

3	
count

The number of items to read, default -1 means all data

4	
offset

The starting position to read from. Default is 0



```python
s = b'hello world'
np.frombuffer(s, dtype='S1', count=5, offset=6)
```




    array([b'w', b'o', b'r', b'l', b'd'], dtype='|S1')



Syntax: numpy.arange(start, stop, step, dtype)


1	
start

The start of an interval. If omitted, defaults to 0

2	
stop

The end of an interval (not including this number)

3	
step

Spacing between values, default is 1

4	
dtype

Data type of resulting ndarray. If not given, data type of input is used


```python
np.arange(10,50,3)
```




    array([10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40, 43, 46, 49])



numpy.linspace(start, stop, num, endpoint, retstep, dtype)

1	
start

The starting value of the sequence

2	
stop

The end value of the sequence, included in the sequence if endpoint set to true

3	
num

The number of evenly spaced samples to be generated. Default is 50

4	
endpoint

True by default, hence the stop value is included in the sequence. If false, it is not included

5	
retstep

If true, returns samples and step between the consecutive numbers

6	
dtype

Data type of output ndarray


```python
x = np.linspace(10,50,25) 
print(x)
```

    [10.         11.66666667 13.33333333 15.         16.66666667 18.33333333
     20.         21.66666667 23.33333333 25.         26.66666667 28.33333333
     30.         31.66666667 33.33333333 35.         36.66666667 38.33333333
     40.         41.66666667 43.33333333 45.         46.66666667 48.33333333
     50.        ]
    


```python
x.mean()
```




    30.0




```python
np.median(x)
```




    30.0



numpy.logspace(start, stop, num, endpoint, base, dtype)


1	
start

The starting point of the sequence is basestart

2	
stop

The final value of sequence is basestop

3	
num

The number of values between the range. Default is 50

4	
endpoint

If true, stop is the last value in the range

5	
base

Base of log space, default is 10

6	
dtype

Data type of output array. If not given, it depends upon other input arguments


```python
a = np.logspace(1.0, 5.0, num = 20) 
print(a)
```

    [1.00000000e+01 1.62377674e+01 2.63665090e+01 4.28133240e+01
     6.95192796e+01 1.12883789e+02 1.83298071e+02 2.97635144e+02
     4.83293024e+02 7.84759970e+02 1.27427499e+03 2.06913808e+03
     3.35981829e+03 5.45559478e+03 8.85866790e+03 1.43844989e+04
     2.33572147e+04 3.79269019e+04 6.15848211e+04 1.00000000e+05]
    


```python
np.size(a)
```




    20




```python
a = np.logspace(1,10,num = 10, base = 2) 
print(a)
```

    [   2.    4.    8.   16.   32.   64.  128.  256.  512. 1024.]
    


```python
a.shape = (2,5) 
```


```python
a
```




    array([[   2.,    4.,    8.,   16.,   32.],
           [  64.,  128.,  256.,  512., 1024.]])




```python
a = np.arange(10)
```


```python
a
```




    array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])




```python
s = slice(2,7,1)
```


```python
s
```




    slice(2, 7, 1)




```python
print(a[s])
```

    [2 3 4 5 6]
    


```python
s = slice(2,7,2)
```


```python
print(a[s])
```

    [2 4 6]
    


```python
'''import re
n=0
a = []
c=108
l,m,n,o,p = input().split()
while c<113:
    s = str(chr(c))
    a.append((re.sub(r'[^\w]',' ',s)))
    c=c+1
print(a)'''
    
```




    "import re\nn=0\na = []\nc=108\nl,m,n,o,p = input().split()\nwhile c<113:\n    s = str(chr(c))\n    a.append((re.sub(r'[^\\w]',' ',s)))\n    c=c+1\nprint(a)"




```python
chr(10)
```




    '\n'




```python
ord('\n')
```




    10




```python
a = np.arange(10) 
print(a[2:])
```

    [2 3 4 5 6 7 8 9]
    


```python
print(a[2:5])
```

    [2 3 4]
    


```python
a = np.array([[1,2,3],[3,4,5],[4,5,6]],dtype='int8')
print(a)
```

    [[1 2 3]
     [3 4 5]
     [4 5 6]]
    


```python
print(a[0:])
```

    [[1 2 3]
     [3 4 5]
     [4 5 6]]
    


```python
print(a[1:])
```

    [[3 4 5]
     [4 5 6]]
    


```python
print(a[2:])
```

    [[4 5 6]]
    


```python
print(a[:1])
```

    [[1 2 3]]
    


```python
print(a[:2])
```

    [[1 2 3]
     [3 4 5]]
    


```python
print(a[:3])
```

    [[1 2 3]
     [3 4 5]
     [4 5 6]]
    


```python
print(a[1:3])
```

    [[3 4 5]
     [4 5 6]]
    


```python
print(a[  [0,1]  ])
```

    [[1 2 3]
     [3 4 5]]
    


```python
print(a[0,1])
```

    2
    


```python
print(a[  [0,2,1]  ])
```

    [[1 2 3]
     [4 5 6]
     [3 4 5]]
    


```python
a = np.array([[1,2,3],[3,4,5],[4,5,6]]) 

print ('Our array is:') 
print(a) 

print('The items in the second column are: ')  
print( a[...,1] )  

# Now we will slice all items from the second row 
print('The items in the second row are:')
print( a[1,...] )


# Now we will slice all items from column 1 onwards 
print( 'The items column 1 onwards are:') 
print( a[...,1:])
```

    Our array is:
    [[1 2 3]
     [3 4 5]
     [4 5 6]]
    The items in the second column are: 
    [2 4 5]
    The items in the second row are:
    [3 4 5]
    The items column 1 onwards are:
    [[2 3]
     [4 5]
     [5 6]]
    


```python
x = np.array([[1, 2], [3, 4], [5, 6]]) 
y = x[[0,1,2], [0,1,0]] 
print(y)
```

    [1 4 5]
    


```python
x[[0,1,2],[0,1,0]]
```




    array([1, 4, 5])




```python
x[[0,1,2],[0]]
```




    array([1, 3, 5])




```python
x[[0,1,2],[1]]
```




    array([2, 4, 6])




```python
x[2]
```




    array([5, 6])




```python
x[[0,1,2]]
```




    array([[1, 2],
           [3, 4],
           [5, 6]])




```python
x[0,1]
```




    2




```python
x[0:1]
```




    array([[1, 2]])




```python
x[:1]
```




    array([[1, 2]])




```python
x[:2]
```




    array([[1, 2],
           [3, 4]])




```python
x[:3]
```




    array([[1, 2],
           [3, 4],
           [5, 6]])




```python
x = np.array([[ 0,  1,  2],[ 3,  4,  5],[ 6,  7,  8],[ 9, 10, 11]]) 
print('array',x,end='\n\n\n')
rows = np.array([[0,0],[3,3]])
cols = np.array([[0,2],[0,2]]) 
y = x[rows,cols] 
print(y)
```

    array [[ 0  1  2]
     [ 3  4  5]
     [ 6  7  8]
     [ 9 10 11]]
    
    
    [[ 0  2]
     [ 9 11]]
    


```python
x[[3,3]]
```




    array([[ 9, 10, 11],
           [ 9, 10, 11]])




```python
x[[0,0]]
```




    array([[0, 1, 2],
           [0, 1, 2]])




```python
x[[0,2]]
```




    array([[0, 1, 2],
           [6, 7, 8]])




```python
cols|rows
```




    array([[0, 2],
           [3, 3]], dtype=int32)




```python
# slicing 
z = x[1:4,1:3] 
```


```python
z
```




    array([[ 4,  5],
           [ 7,  8],
           [10, 11]])




```python
x[1:2,1:]
```




    array([[4, 5]])




```python
x[1:,1:]
```




    array([[ 4,  5],
           [ 7,  8],
           [10, 11]])




```python
x[1:1,1:]
```




    array([], shape=(0, 2), dtype=int32)




```python
a = np.array([1, 2+6j, 5, 3.5+5j]) 
print(a[np.iscomplex(a)])
```

    [2. +6.j 3.5+5.j]
    


```python
#Boardcasting
a = np.array([1,2,3,4]) 
b = np.array([10,20,30,40]) 
c = a * b 
print(c)
```

    [ 10  40  90 160]
    


```python
a = np.array([[0.0,0.0,0.0],[10.0,10.0,10.0],[20.0,20.0,20.0],[30.0,30.0,30.0]]) 
b = np.array([1.0,2.0,3.0])  
```


```python
a,b
```




    (array([[ 0.,  0.,  0.],
            [10., 10., 10.],
            [20., 20., 20.],
            [30., 30., 30.]]), array([1., 2., 3.]))




```python
print(a+b)
```

    [[ 1.  2.  3.]
     [11. 12. 13.]
     [21. 22. 23.]
     [31. 32. 33.]]
    


```python
print(a*b)
```

    [[ 0.  0.  0.]
     [10. 20. 30.]
     [20. 40. 60.]
     [30. 60. 90.]]
    


```python
a = np.arange(0,60,5) 
a = a.reshape(3,4) 
```


```python
a
```




    array([[ 0,  5, 10, 15],
           [20, 25, 30, 35],
           [40, 45, 50, 55]])




```python
#Transpose
b = a.T 
```


```python
b
```




    array([[ 0, 20, 40],
           [ 5, 25, 45],
           [10, 30, 50],
           [15, 35, 55]])




```python
print('Sorted in C-style order:')
c = b.copy(order = 'C')
```

    Sorted in C-style order:
    


```python
c
```




    array([[ 0, 20, 40],
           [ 5, 25, 45],
           [10, 30, 50],
           [15, 35, 55]])




```python
for x in np.nditer(c):
    print(x)
```

    0
    20
    40
    5
    25
    45
    10
    30
    50
    15
    35
    55
    


```python
#F Order
print(b.copy(order = 'F'))
```

    [[ 0 20 40]
     [ 5 25 45]
     [10 30 50]
     [15 35 55]]
    


```python
c
```




    array([[ 0, 20, 40],
           [ 5, 25, 45],
           [10, 30, 50],
           [15, 35, 55]])




```python
#It is possible to force nditer object to use a specific order by explicitly mentioning it.

for x in np.nditer(a, order = 'C'): 
     print(x)
```

    0
    5
    10
    15
    20
    25
    30
    35
    40
    45
    50
    55
    


```python
for x in np.nditer(a, order = 'F'): 
     print(x)
```

    0
    20
    40
    5
    25
    45
    10
    30
    50
    15
    35
    55
    


```python
a = np.arange(0,60,5)
a = a.reshape(3,4)
```


```python
a
```




    array([[ 0,  5, 10, 15],
           [20, 25, 30, 35],
           [40, 45, 50, 55]])




```python
for x in np.nditer(a, op_flags = ['readwrite']):
     x[...] = 2*x
print('Modified array is:')
print( a)
```

    Modified array is:
    [[  0  10  20  30]
     [ 40  50  60  70]
     [ 80  90 100 110]]
    

External Loop
The nditer class constructor has a ‘flags’ parameter, which can take the following values −

Sr.No.	Parameter & Description
1	
c_index

C_order index can be tracked

2	
f_index

Fortran_order index is tracked

3	
multi-index

Type of indexes with one per iteration can be tracked

4	
external_loop

Causes values given to be one-dimensional arrays with multiple values instead of zero-dimensional array


```python
a = np.arange(0,60,5) 
a = a.reshape(3,4) 
for x in np.nditer(a, flags = ['external_loop'], order = 'F'):
            print( x)
```

    [ 0 20 40]
    [ 5 25 45]
    [10 30 50]
    [15 35 55]
    


```python
b = np.array([1, 2, 3, 4], dtype = int)
```


```python
b
```




    array([1, 2, 3, 4])




```python
for x,y in np.nditer([a,b]): 
     print( "%d:%d" % (x,y))
```

    0:1
    5:2
    10:3
    15:4
    20:1
    25:2
    30:3
    35:4
    40:1
    45:2
    50:3
    55:4
    

Transpose Operations
Sr.No.	Operation & Description

1	transpose
Permutes the dimensions of an array

2	ndarray.T
Same as self.transpose()

3	rollaxis
Rolls the specified axis backwards

4	swapaxes
Interchanges the two axes of an array

Changing Dimensions
Sr.No.	Dimension & Description

1	broadcast
Produces an object that mimics broadcasting

2	broadcast_to
Broadcasts an array to a new shape

3	expand_dims
Expands the shape of an array

4	squeeze
Removes single-dimensional entries from the shape of an array

Joining Arrays
Sr.No.	Array & Description

1	concatenate
Joins a sequence of arrays along an existing axis

2	stack
Joins a sequence of arrays along a new axis

3	hstack
Stacks arrays in sequence horizontally (column wise)

4	vstack
Stacks arrays in sequence vertically (row wis

Splitting Arrays
Sr.No.	Array & Description

1	split
Splits an array into multiple sub-arrays

2	hsplit
Splits an array into multiple sub-arrays horizontally (column-wise)

3	vsplit
Splits an array into multiple sub-arrays vertically (row-wise)

Adding / Removing Elements
Sr.No.	Element & Description

1	resize
Returns a new array with the specified shape

2	append
Appends the values to the end of an array

3	insert
Inserts the values along the given axis before the given indices

4	delete
Returns a new array with sub-arrays along an axis deleted

5	unique
Finds the unique elements of an array

Adding / Removing Elements
Sr.No.	Element & Description

1	resize
Returns a new array with the specified shape

2	append
Appends the values to the end of an array

3	insert
Inserts the values along the given axis before the given indices

4	delete
Returns a new array with sub-arrays along an axis deleted

5	unique
Finds the unique elements of an array

Sr.No.	Function & Description

1	add()
Returns element-wise string concatenation for two arrays of str or Unicode

2	multiply()
Returns the string with multiple concatenation, element-wise

3	center()
Returns a copy of the given string with elements centered in a string of specified length

4	capitalize()
Returns a copy of the string with only the first character capitalized

5	title()
Returns the element-wise title cased version of the string or unicode

6	lower()
Returns an array with the elements converted to lowercase

7	upper()
Returns an array with the elements converted to uppercase

8	split()
Returns a list of the words in the string, using separatordelimiter

9	splitlines()
Returns a list of the lines in the element, breaking at the line boundaries

10	strip()
Returns a copy with the leading and trailing characters removed

11	join()
Returns a string which is the concatenation of the strings in the sequence

12	replace()
Returns a copy of the string with all occurrences of substring replaced by the new string

13	decode()
Calls str.decode element-wise

14	encode()
Calls str.encode element-wise


```python
print( 'Bitwise AND of 13 and 17:') 
print( np.bitwise_and(13, 17))
```

    Bitwise AND of 13 and 17:
    1
    

BITWISE OPERATION

Sr.No.	Operation & Description

1	bitwise_and
Computes bitwise AND operation of array elements

2	bitwise_or
Computes bitwise OR operation of array elements

3	invert
Computes bitwise NOT

4	left_shift
Shifts bits of a binary representation to the left

5	right_shift
Shifts bits of binary representation to the right

STRING OPERATION

Sr.No.	Function & Description

1	add()
Returns element-wise string concatenation for two arrays of str or Unicode

2	multiply()
Returns the string with multiple concatenation, element-wise

3	center()
Returns a copy of the given string with elements centered in a string of specified length

4	capitalize()
Returns a copy of the string with only the first character capitalized

5	title()
Returns the element-wise title cased version of the string or unicode

6	lower()
Returns an array with the elements converted to lowercase

7	upper()
Returns an array with the elements converted to uppercase

8	split()
Returns a list of the words in the string, using separatordelimiter

9	splitlines()
Returns a list of the lines in the element, breaking at the line boundaries

10	strip()
Returns a copy with the leading and trailing characters removed

11	join()
Returns a string which is the concatenation of the strings in the sequence

12	replace()
Returns a copy of the string with all occurrences of substring replaced by the new string

13	decode()
Calls str.decode element-wise

14	encode()
Calls str.encode element-wise


```python
a = np.array([0,30,45,60,90]) 

print( 'Sine of different angles:') 
# Convert to radians by multiplying with pi/180 
print(np.sin(a*np.pi/180)) 
print( '\n')  

print( 'Cosine values for angles in array:') 
print(np.cos(a*np.pi/180) )
print( '\n')  

print('Tangent values for given angles:')
print(np.tan(a*np.pi/180) )
```

    Sine of different angles:
    [0.         0.5        0.70710678 0.8660254  1.        ]
    
    
    Cosine values for angles in array:
    [1.00000000e+00 8.66025404e-01 7.07106781e-01 5.00000000e-01
     6.12323400e-17]
    
    
    Tangent values for given angles:
    [0.00000000e+00 5.77350269e-01 1.00000000e+00 1.73205081e+00
     1.63312394e+16]
    


```python
a = np.array([0,30,45,60,90])
```


```python
a
```




    array([ 0, 30, 45, 60, 90])




```python
np.sin(a*np.pi/180)
```




    array([0.        , 0.5       , 0.70710678, 0.8660254 , 1.        ])




```python
#'Compute sine inverse of angles. Returned values are in radians.'
sin = np.sin(a*np.pi/180)
np.arcsin(sin) 
```




    array([0.        , 0.52359878, 0.78539816, 1.04719755, 1.57079633])




```python
print('Check result by converting to degrees:' )
inv = np.arcsin(sin) 
print(np.degrees(inv))
```

    Check result by converting to degrees:
    [ 0. 30. 45. 60. 90.]
    


```python
cos =( np.cos(a*np.pi/180)) 
print( cos) 
```

    [1.00000000e+00 8.66025404e-01 7.07106781e-01 5.00000000e-01
     6.12323400e-17]
    


```python
#inverse of cos is sec
print( 'Inverse of cos:' )
inv =( np.arccos(cos)) 
print( inv)
```

    Inverse of cos:
    [0.         0.52359878 0.78539816 1.04719755 1.57079633]
    


```python
print( 'In degrees:') 
print( np.degrees(inv)) 
```

    In degrees:
    [ 0. 30. 45. 60. 90.]
    


```python
np.tan(a*np.pi/180) 
```




    array([0.00000000e+00, 5.77350269e-01, 1.00000000e+00, 1.73205081e+00,
           1.63312394e+16])




```python
a = np.arange(9, dtype = np.float_).reshape(3,3) 
```


```python
a
```




    array([[0., 1., 2.],
           [3., 4., 5.],
           [6., 7., 8.]])




```python
np.cos(a*np.pi/180)
```




    array([[1.        , 0.9998477 , 0.99939083],
           [0.99862953, 0.99756405, 0.9961947 ],
           [0.9945219 , 0.99254615, 0.99026807]])




```python
#Array Operations
a = np.arange(9, dtype = np.float_).reshape(3,3) 
b = np.array([10,10,10])
```


```python
a, b
```




    (array([[0., 1., 2.],
            [3., 4., 5.],
            [6., 7., 8.]]), array([10, 10, 10]))




```python
print( 'Add the two arrays:') 
print( np.add(a,b)) 
```

    Add the two arrays:
    [[10. 11. 12.]
     [13. 14. 15.]
     [16. 17. 18.]]
    


```python
print( 'Subtract the two arrays:') 
print( np.subtract(a,b))
```

    Subtract the two arrays:
    [[-10.  -9.  -8.]
     [ -7.  -6.  -5.]
     [ -4.  -3.  -2.]]
    


```python
print( 'Multiply the two arrays:') 
print( np.multiply(a,b))
```

    Multiply the two arrays:
    [[ 0. 10. 20.]
     [30. 40. 50.]
     [60. 70. 80.]]
    


```python
print( 'Divide the two arrays:') 
print( np.divide(a,b))
```

    Divide the two arrays:
    [[0.  0.1 0.2]
     [0.3 0.4 0.5]
     [0.6 0.7 0.8]]
    


```python
print( 'Matrix multiplication of two arrays the two arrays:') 
print( np.matmul(a,b))
```

    Matrix multiplication of two arrays the two arrays:
    [ 30. 120. 210.]
    

numpy.reciprocal()
This function returns the reciprocal of argument, element-wise. For elements with 
absolute values larger than 1, the result is always 0 because of the way in which Python handles integer division. 
For integer 0, an overflow warning is issued.


```python
a = np.array([0.25, 1.33, 1, 0, 100])
print(a)
```

    [  0.25   1.33   1.     0.   100.  ]
    


```python
print( np.reciprocal(a)) 
```

    [4.        0.7518797 1.              inf 0.01     ]
    

    C:\Users\sridhar\Anaconda3\lib\site-packages\ipykernel_launcher.py:1: RuntimeWarning: divide by zero encountered in reciprocal
      """Entry point for launching an IPython kernel.
    


```python
print(np.reciprocal(a))
```

    [4.        0.7518797 1.              inf 0.01     ]
    

    C:\Users\sridhar\Anaconda3\lib\site-packages\ipykernel_launcher.py:1: RuntimeWarning: divide by zero encountered in reciprocal
      """Entry point for launching an IPython kernel.
    


```python
b = np.array([100], dtype = float) 
```


```python
b
```




    array([100.])




```python
print(np.reciprocal(b))
```

    [0.01]
    


```python
a = np.array([10,100,1000]) 
```


```python
a
```




    array([  10,  100, 1000])




```python
#Return Power of the Values
print( 'Applying power function:' )
print( np.power(a,2)) 
```

    Applying power function:
    [    100   10000 1000000]
    


```python
b =( np.array([1,2,3])) 
print( b) 
```

    [1 2 3]
    


```python
np.power(a,b)
```




    array([        10,      10000, 1000000000], dtype=int32)




```python
print( 'Applying power function again:') 
print( np.power(a,b))
```

    Applying power function again:
    [        10      10000 1000000000]
    

numpy.mod()

This function returns the remainder of division of the corresponding elements 
in the input array. The function numpy.remainder() also produces the same result.


```python
a = np.array([10,20,30]) 
b = np.array([3,5,7])
```


```python
a,b
```




    (array([10, 20, 30]), array([3, 5, 7]))




```python
print( np.mod(a,b)) 
```

    [1 0 2]
    


```python
print(np.remainder(a,b))
```

    [1 0 2]
    

The following functions are used to perform operations on array with complex numbers.

numpy.real() − returns the real part of the complex data type argument.

numpy.imag() − returns the imaginary part of the complex data type argument.

numpy.conj() − returns the complex conjugate, which is obtained by changing the sign of the imaginary part.

numpy.angle() − returns the angle of the complex argument. The function has degree parameter. If true, the angle in the degree is returned, otherwise the angle is in radians.


```python
a = np.array([-5.6j, 0.2j, 11. , 1+1j]) 
```


```python
a
```




    array([-0.-5.6j,  0.+0.2j, 11.+0.j ,  1.+1.j ])




```python
np.real(a)
```




    array([-0.,  0., 11.,  1.])




```python
np.imag(a)
```




    array([-5.6,  0.2,  0. ,  1. ])




```python
#Inverse the sign of complex numbers
np.conj(a) 
```




    array([-0.+5.6j,  0.-0.2j, 11.-0.j ,  1.-1.j ])




```python
np.angle(a)
```




    array([-1.57079633,  1.57079633,  0.        ,  0.78539816])




```python
np.angle(a, deg = True)
```




    array([-90.,  90.,   0.,  45.])




```python
#min and max of numpy don't work on complex numbers
a = np.array([[3,7,5],[8,4,3],[2,4,9]]) 
np.amin(a,1) 
```




    array([3, 3, 2])




```python
#print minimum values of rows
np.amin(a,1)
```




    array([3, 3, 2])




```python
#print the minium values of coloumns
np.amin(a,0)
```




    array([2, 4, 3])




```python
#Returns the Maximum Values of the array
np.amax(a)
```




    9




```python
#return the maximum values of the coloumns
np.amax(a, axis=0)
```




    array([8, 7, 9])




```python
#return the maximum values of the rows
np.amax(a, axis=0)
```




    array([8, 7, 9])



numpy.ptp()


The numpy.ptp() function returns the range (maximum-minimum) of values along an axis.


```python
a = np.array([[3,7,5],[8,4,3],[2,4,9]]) 
```


```python
# returns maximum-mininum in array(a)
np.ptp(a)
```




    7




```python
# returns maximum-mininum in row
np.ptp(a, axis = 1) 
```




    array([4, 5, 7])




```python
# returns maximum-mininum in columns
np.ptp(a, axis = 0)
```




    array([6, 3, 6])



numpy.percentile()


Percentile (or a centile) is a measure used in statistics indicating the value below which a given percentage of observations in a group of observations fall. The function numpy.percentile() takes the following arguments.


Sr.No.	Argument & Description

1	a

Input array

2	q

The percentile to compute must be between 0-100

3	axis

The axis along which the percentile is to be calculated


```python
a = np.array([[30,40,70],[80,20,10],[50,90,60]]) 
```


```python
np.percentile(a,50)
```




    50.0




```python
np.percentile(a,30)
```




    34.0




```python
np.percentile(a,50, axis = 1) 
```




    array([40., 20., 60.])




```python
np.percentile(a,50, axis = 0) 
```




    array([50., 40., 60.])




```python
np.percentile(a,50, axis = 0)
```




    array([50., 40., 60.])



numpy.median()


Median is defined as the value separating the higher half of a data sample from the lower half. The numpy.median() function is used as shown in the following program.


```python
np.median(a)
```




    50.0




```python
a
```




    array([[30, 40, 70],
           [80, 20, 10],
           [50, 90, 60]])




```python
np.median(a, axis = 0)
```




    array([50., 40., 60.])




```python
np.median(a, axis = 1)
```




    array([40., 20., 60.])



numpy.mean()


Arithmetic mean is the sum of elements along an axis divided by the number of elements. The numpy.mean() function returns the arithmetic mean of elements in the array. If the axis is mentioned, it is calculated along it.


```python
a = np.array([[1,2,3],[3,4,5],[4,5,6]]) 
```


```python
np.mean(a)
```




    3.6666666666666665




```python
np.mean(a, axis = 0)
```




    array([2.66666667, 3.66666667, 4.66666667])




```python
np.mean(a, axis = 1)
```




    array([2., 4., 5.])



numpy.average()


Weighted average is an average resulting from the multiplication of each component by a factor reflecting its importance. The numpy.average() function computes the weighted average of elements in an array according to their respective weight given in another array. The function can have an axis parameter. If the axis is not specified, the array is flattened.

Considering an array [1,2,3,4] and corresponding weights [4,3,2,1], the weighted average is calculated by adding the product of the corresponding elements and dividing the sum by the sum of weights.

Weighted average = (1*4+2*3+3*2+4*1)/(4+3+2+1)


```python
np.average(a, axis = 1)
```




    array([2., 4., 5.])




```python
np.average(a, axis = 0)
```




    array([2.66666667, 3.66666667, 4.66666667])




```python
np.average(a)
```




    3.6666666666666665



Standard Deviation


Standard deviation is the square root of the average of squared deviations from mean. The formula for standard deviation is as follows −

std = sqrt(mean(abs(x - x.mean())**2))


```python
np.std([10,20,30,40,50])
```




    14.142135623730951



Variance
Variance is the average of squared deviations, i.e., mean(abs(x - x.mean())**2). In other words, the standard deviation is the square root of variance.


```python
np.var([1,2,3,4])
```




    1.25




```python
a=np.array([[3,7],[9,1]]) 
```


```python

np.sort(a)
```




    array([[3, 7],
           [1, 9]])




```python
np.sort(a, axis = 0) 
```




    array([[3, 1],
           [9, 7]])




```python
np.sort(a, axis = 1) 
```




    array([[3, 7],
           [1, 9]])




```python
a.itemsize
```




    4



numpy.argsort()


The numpy.argsort() function performs an indirect sort on input array, along the given axis and using a specified kind of sort to return the array of indices of data. This indices array is used to construct the sorted array.


```python
x = np.array([3, 1, 2]) 
```


```python
x
```




    array([3, 1, 2])




```python
y= np.argsort(x)
y
```




    array([1, 2, 0], dtype=int64)




```python
#get the sorted values use this
x[y] 
```




    array([1, 2, 3])




```python
#'Index of maximum number in flattened array' 

```


```python
a.flatten()
```




    array([3, 7, 9, 1])



numpy.lexsort()

function performs an indirect sort using a sequence of keys. The keys can be seen as a column in a spreadsheet. The function returns an array of indices, using which the sorted data can be obtained. Note, that the last key happens to be the primary key of sort.


```python
nm = ('raju','anil','ravi','amar') 
dv = ('f.y.', 's.y.', 's.y.', 'f.y.') 
ind = np.lexsort((dv,nm)) 
```


```python
ind
```




    array([3, 1, 0, 2], dtype=int64)




```python
np.argmax(a) 
```




    2




```python
np.argmin(a) 
```




    3




```python
#'Use this index to get sorted data:' 

[nm[i] + ", " + dv[i] for i in ind] 
```




    ['amar, f.y.', 'anil, s.y.', 'raju, f.y.', 'ravi, s.y.']



numpy.nonzero()
The numpy.nonzero() function returns the indices of non-zero elements in the input array.


```python
a = np.array([[30,40,0],[0,20,10],[50,0,60]]) 
```


```python
print( a )
```

    [[30 40  0]
     [ 0 20 10]
     [50  0 60]]
    


```python
print( np.nonzero (a))
```

    (array([0, 0, 1, 1, 2, 2], dtype=int64), array([0, 1, 1, 2, 0, 2], dtype=int64))
    


```python
y = np.where(x > 3) 
```


```python
print(y)
```

    (array([], dtype=int64),)
    


```python
print(a[y])
```

    []
    


```python
x = np.arange(9.).reshape(3, 3) 
```


```python
x
```




    array([[0., 1., 2.],
           [3., 4., 5.],
           [6., 7., 8.]])




```python
y = np.where(x > 3) 
```


```python
y
```




    (array([1, 1, 2, 2, 2], dtype=int64), array([1, 2, 0, 1, 2], dtype=int64))




```python
#Use these indices to get elements satisfying the condition' 
x[y]
```




    array([4., 5., 6., 7., 8.])



numpy.extract()


The extract() function returns the elements satisfying any condition


```python
x = np.arange(9.).reshape(3, 3) 
```


```python
condition = np.mod(x,2) == 0 
```


```python
condition
```




    array([[ True, False,  True],
           [False,  True, False],
           [ True, False,  True]])




```python
np.extract(condition, x)
```




    array([0., 2., 4., 6., 8.])



numpy.ndarray.byteswap()

The numpy.ndarray.byteswap() function toggles between the two representations: bigendian and little-endian.


```python
a = np.array([1, 256, 8755], dtype = np.int16) 
```


```python
a
```




    array([   1,  256, 8755], dtype=int16)



No Copy

Simple assignments do not make the copy of array object. Instead, it uses the same id() of the original array to access it. The id() returns a universal identifier of Python object, similar to the pointer in C.

Furthermore, any changes in either gets reflected in the other. For example, the changing shape of one will change the shape of the other too.


```python
a = np.arange(6)
a
```




    array([0, 1, 2, 3, 4, 5])




```python
id(a)
```




    2554280014832




```python
b = a 
```


```python
id(b)
```




    2554280015392




```python
b.shape = (3,2)
```


```python
a
```




    array([[0, 1],
           [2, 3],
           [4, 5]])




```python
b
#if b cahnges a also changes
```




    array([[0, 1],
           [2, 3],
           [4, 5]])



View or Shallow Copy

NumPy has ndarray.view() method which is a new array object that looks at the same data of the original array. Unlike the earlier case, change in dimensions of the new array doesn’t change dimensions of the original.


```python
a = np.arange(6).reshape(3,2) 
```


```python
a
```




    array([[0, 1],
           [2, 3],
           [4, 5]])




```python
b = a.view() 
```


```python
b
```




    array([[0, 1],
           [2, 3],
           [4, 5]])




```python
id(b)
```




    2554280017152




```python
b.shape = (2,3)
```


```python
b
```




    array([[0, 1, 2],
           [3, 4, 5]])




```python
a
#now you can see if u change value of b, a value doesn't change
```




    array([[0, 1],
           [2, 3],
           [4, 5]])




```python
a = np.array([[10,10], [2,3], [4,5]]) 
```


```python
a
```




    array([[10, 10],
           [ 2,  3],
           [ 4,  5]])




```python
s = a[:, :2] 
```


```python
s
```




    array([[10, 10],
           [ 2,  3],
           [ 4,  5]])



Deep Copy

The ndarray.copy() function creates a deep copy. It is a complete copy of the array and its data, and doesn’t share with the original array.


```python
a = np.array([[10,10], [2,3], [4,5]]) 
a
```




    array([[10, 10],
           [ 2,  3],
           [ 4,  5]])




```python
b = a.copy() 
```


```python
b
```




    array([[10, 10],
           [ 2,  3],
           [ 4,  5]])




```python
a
```




    array([[10, 10],
           [ 2,  3],
           [ 4,  5]])




```python
#b does not share any memory of a 
print( b is a )
```

    False
    


```python
b[0,0] = 100 
```


```python
b,a
```




    (array([[100,  10],
            [  2,   3],
            [  4,   5]]), array([[10, 10],
            [ 2,  3],
            [ 4,  5]]))




```python
#the values doesn't changed
```

NumPy package contains a Matrix library numpy.matlib. This module has functions that return matrices instead of ndarray objects.

matlib.empty()
The matlib.empty() function returns a new matrix without initializing the entries. The function takes the following parameters.

numpy.matlib.empty(shape, dtype, order)



Where,

Sr.No.	Parameter & Description
1	shape

int or tuple of int defining the shape of the new matrix

2	Dtype

Optional. Data type of the output

3	order

C or F


```python
import numpy.matlib
```


```python
print( np.matlib.empty((2,2))) 
```

    [[2. 4.]
     [6. 8.]]
    

numpy.matlib.zeros()
This function returns the matrix filled with zero


```python
np.matlib.zeros((2,2))
```




    matrix([[0., 0.],
            [0., 0.]])




```python
np.matlib.ones((2,2))
```




    matrix([[1., 1.],
            [1., 1.]])



numpy.matlib.eye()

This function returns a matrix with 1 along the diagonal elements and the zeros elsewhere. The function takes the following parameters.

numpy.matlib.eye(n, M,k, dtype)


Where,

Sr.No.	Parameter & Description
1	n   The number of rows in the resulting matrix

2	M
The number of columns, defaults to n

3	k
Index of diagonal

4	dtype
Data type of the output


```python
np.matlib.eye(n = 3, M = 4, k = 0, dtype = float)
```




    matrix([[1., 0., 0., 0.],
            [0., 1., 0., 0.],
            [0., 0., 1., 0.]])



numpy.matlib.identity()


The numpy.matlib.identity() function returns the Identity matrix of the given size. An identity matrix is a square matrix with all diagonal elements as 1.


```python
np.matlib.identity(5, dtype = float)
```




    matrix([[1., 0., 0., 0., 0.],
            [0., 1., 0., 0., 0.],
            [0., 0., 1., 0., 0.],
            [0., 0., 0., 1., 0.],
            [0., 0., 0., 0., 1.]])




```python
np.matlib.rand(3,3)
```




    matrix([[0.17266136, 0.84428654, 0.89410422],
            [0.77686325, 0.54908283, 0.17212633],
            [0.67403301, 0.17110971, 0.296597  ]])




```python
np.matrix('1,2;3,4') 
```




    matrix([[1, 2],
            [3, 4]])




```python
np.asmatrix (j)
```




    matrix([[1, 2],
            [3, 4]])



NumPy package contains numpy.linalg module that provides all the functionality required for linear algebra. Some of the important functions in this module are described in the following table.

Sr.No.	Function & Description
1	dot
Dot product of the two arrays

2	vdot
Dot product of the two vectors

3	inner
Inner product of the two arrays

4	matmul
Matrix product of the two arrays

5	determinant
Computes the determinant of the array

6	solve
Solves the linear matrix equation

7	inv
Finds the multiplicative inverse of the matrix


```python
from matplotlib import pyplot as plt 
```


```python
x = np.arange(1,11) 
y = 2 * x + 5 
plt.title("Matplotlib demo") 
plt.xlabel("x axis caption") 
plt.ylabel("y axis caption") 
plt.plot(x,y) 
plt.show()
```


![png](output_319_0.png)


Sr.No.	Character & Description
1	
'-'

Solid line style

2	
'--'

Dashed line style

3	
'-.'

Dash-dot line style

4	
':'

Dotted line style

5	
'.'

Point marker

6	
','

Pixel marker

7	
'o'

Circle marker

8	
'v'

Triangle_down marker

9	
'^'

Triangle_up marker

10	
'<'

Triangle_left marker

11	
'>'

Triangle_right marker

12	
'1'

Tri_down marker

13	
'2'

Tri_up marker

14	
'3'

Tri_left marker

15	
'4'

Tri_right marker

16	
's'

Square marker

17	
'p'

Pentagon marker

18	
'*'

Star marker

19	
'h'

Hexagon1 marker

20	
'H'

Hexagon2 marker

21	
'+'

Plus marker

22	
'x'

X marker

23	
'D'

Diamond marker

24	
'd'

Thin_diamond marker

25	
'|'

Vline marker

26	
'_'

Hline marker

The following color abbreviations are also defined.

Character	Color
'b'	Blue
'g'	Green
'r'	Red
'c'	Cyan
'm'	Magenta
'y'	Yellow
'k'	Black
'w'	Whi


```python
x = np.arange(1,11) 
y = 2 * x + 5 
plt.title("Matplotlib demo") 
plt.xlabel("x axis caption") 
plt.ylabel("y axis caption") 
plt.plot(x,y,"ob") 
plt.show() 
```


![png](output_321_0.png)



```python
# Compute the x and y coordinates for points on a sine curve 
x = np.arange(0, 3 * np.pi, 0.1) 
y = np.sin(x) 
plt.title("sine wave form") 

# Plot the points using matplotlib 
plt.plot(x, y) 
plt.show()
```


![png](output_322_0.png)



```python
x = np.arange(0, 3 * np.pi, 0.1) 
y_sin = np.sin(x) 
y_cos = np.cos(x)  
   
# Set up a subplot grid that has height 2 and width 1, 
# and set the first such subplot as active. 
plt.subplot(2, 1, 1)
   
# Make the first plot 
plt.plot(x, y_sin) 
plt.title('Sine')  
   
# Set the second subplot as active, and make the second plot. 
plt.subplot(2, 1, 2) 
plt.plot(x, y_cos) 
plt.title('Cosine')  
   
# Show the figure. 
plt.show()
```


![png](output_323_0.png)



```python
y
```




    array([ 0.        ,  0.09983342,  0.19866933,  0.29552021,  0.38941834,
            0.47942554,  0.56464247,  0.64421769,  0.71735609,  0.78332691,
            0.84147098,  0.89120736,  0.93203909,  0.96355819,  0.98544973,
            0.99749499,  0.9995736 ,  0.99166481,  0.97384763,  0.94630009,
            0.90929743,  0.86320937,  0.8084964 ,  0.74570521,  0.67546318,
            0.59847214,  0.51550137,  0.42737988,  0.33498815,  0.23924933,
            0.14112001,  0.04158066, -0.05837414, -0.15774569, -0.2555411 ,
           -0.35078323, -0.44252044, -0.52983614, -0.61185789, -0.68776616,
           -0.7568025 , -0.81827711, -0.87157577, -0.91616594, -0.95160207,
           -0.97753012, -0.993691  , -0.99992326, -0.99616461, -0.98245261,
           -0.95892427, -0.92581468, -0.88345466, -0.83226744, -0.77276449,
           -0.70554033, -0.63126664, -0.55068554, -0.46460218, -0.37387666,
           -0.2794155 , -0.1821625 , -0.0830894 ,  0.0168139 ,  0.1165492 ,
            0.21511999,  0.31154136,  0.40484992,  0.49411335,  0.57843976,
            0.6569866 ,  0.72896904,  0.79366786,  0.85043662,  0.8987081 ,
            0.93799998,  0.96791967,  0.98816823,  0.99854335,  0.99894134,
            0.98935825,  0.96988981,  0.94073056,  0.90217183,  0.85459891,
            0.79848711,  0.7343971 ,  0.66296923,  0.58491719,  0.50102086,
            0.41211849,  0.31909836,  0.22288991,  0.12445442,  0.02477543])




```python
from matplotlib import pyplot as plt 
x = [5,8,10] 
y = [12,16,6]  

x2 = [6,9,11] 
y2 = [6,15,7] 
plt.bar(x, y, align = 'center') 
plt.bar(x2, y2, color = 'g', align = 'center') 
plt.title('Bar graph') 
plt.ylabel('Y axis') 
plt.xlabel('X axis')  

plt.show()
```


![png](output_325_0.png)



```python
a = np.array([22,87,5,43,56,73,55,54,11,20,51,5,79,31,27]) 
np.histogram(a,bins = [0,20,40,60,80,100]) 
hist,bins = np.histogram(a,bins = [0,20,40,60,80,100]) 
```


```python
a = np.array([22,87,5,43,56,73,55,54,11,20,51,5,79,31,27]) 
plt.hist(a, bins = [0,20,40,60,80,100]) 
plt.title("histogram") 
plt.show()
```


![png](output_327_0.png)



```python
#Save File
a = np.array([1,2,3,4,5]) 
np.save('outfile',a)
```


```python
#Save Text
```
